   
        let url = window.location.href;
        let ext = url.split('/');
        let extIndex = ext[ext.length-1];
        //console.log(extIndex);
        let extt = extIndex.split('.');
        //console.log(extt);
        let pageName = extt[0];
        //console.log(pageName);
        if(pageName == "practice"){
        document.getElementById('aa').style.backgroundColor = "red";
}