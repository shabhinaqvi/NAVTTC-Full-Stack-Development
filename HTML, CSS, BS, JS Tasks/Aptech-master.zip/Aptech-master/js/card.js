




function reg(){
    var cat = document.getElementById('category').Value;
    var make = document.getElementById('make').Value;
    var model = document.getElementById('model').Value;
    var price = document.getElementById('price').Value;
    var pic = document.getElementById('pic').Value;
    console.log(cat);
    var productDetails = {category: cat, make: make, model: model, price: price, picture: pic};
    
    localStorage.setItem('productDetails',productDetails);

}
// reg();